/*
 * Copyright (C) 2011 www.itcsolutions.eu
 *
 * This file is free software; you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published
 * by the Free Software Foundation; either version 2.1, or (at your
 * option) any later version.
 *
 * This file is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 *
 */

/**
 *
 * @author Catalin - www.itcsolutions.eu
 * @version 2011
 *
 */
package eu.itcsolutions.android.tutorial;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

//implement the OnClickListener interface
public class MainActivity extends Activity 
	implements OnClickListener {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);
        
    	//get the Button reference
    	//Button is a subclass of View 
    	//buttonClick if from main.xml "@+id/buttonClick"
        View btnClick = findViewById(R.id.buttonClick);
        //set event listener
        btnClick.setOnClickListener(this);
    }

    //override the OnClickListener interface method
	@Override
	public void onClick(View arg0) {
		if(arg0.getId() == R.id.buttonClick){
			//define a new Intent for the second Activity
			Intent intent = new Intent(this,SecondActivity.class);
			//start the second Activity
			this.startActivity(intent);
		}
	}
}